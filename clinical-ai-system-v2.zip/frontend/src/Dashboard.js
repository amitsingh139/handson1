import React,{useState} from "react";
import axios from "axios";

export default function Dashboard(){
 const [res,setRes]=useState(null);

 const run=async()=>{
  const r=await axios.post("http://localhost:8000/predict",{
    age:65,heart_rate:90,bp:150,glucose:180,gender:1,ethnicity:0
  });
  setRes(r.data);
 };

 return(
  <div style={{padding:20}}>
   <button onClick={run}>Run Prediction</button>
   {res && (
    <div>
     <p>Risk: {res.risk}</p>
     <p>Risk Confidence: {res.risk_confidence}</p>
     <p>Bias Score: {res.bias_score}</p>
     <p>LLM Confidence: {res.llm_confidence}</p>
     <p>Overall Score: {res.overall_score}</p>
     <pre>{JSON.stringify(res,null,2)}</pre>
    </div>
   )}
  </div>
 );
}
