import random

def llm_confidence(output):
    return round(random.uniform(0.7, 0.95),2)

def explanation_quality(explanation):
    return round(min(1.0, len(str(explanation))/100),2)

def overall_score(risk_conf, bias_score, llm_conf):
    return round((risk_conf + (1-bias_score) + llm_conf)/3,2)
