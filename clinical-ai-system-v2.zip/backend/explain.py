import shap

class Explainer:
    def __init__(self, model):
        self.explainer = shap.Explainer(model)

    def explain(self, patient):
        return self.explainer([patient]).values.tolist()
