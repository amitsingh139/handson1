def who_guidelines(patient, risk):
    g=[]
    if patient["bp"]>140: g.append("WHO: Monitor hypertension")
    if patient["age"]>60: g.append("WHO: Elderly monitoring")
    if risk=="High": g.append("WHO: Critical care")
    return g
