from fairlearn.metrics import demographic_parity_difference

def compute_bias_score(y_true, y_pred, sensitive):
    dp = demographic_parity_difference(y_true, y_pred, sensitive_features=sensitive)
    bias_score = abs(dp)
    return bias_score, bias_score > 0.1
