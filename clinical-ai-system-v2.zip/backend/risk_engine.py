def categorize_risk(score):
    if score < 0.3: return "Low"
    elif score < 0.7: return "Medium"
    return "High"

def get_complications_with_probabilities(score):
    if score >= 0.7:
        return {"Cardiac Arrest":0.9,"Stroke":0.85,"Organ Failure":0.8}
    elif score >= 0.3:
        return {"Hypertension":0.6,"Infection":0.5}
    else:
        return {"Mild Issues":0.3}
