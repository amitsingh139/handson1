def validate_output(text):
    forbidden = ["prescribe","must take","confirmed diagnosis"]
    for f in forbidden:
        if f in text.lower():
            return False
    return True

def generate_decision(patient, risk, comp, guidelines):
    output = f"Risk {risk}. Follow guidelines {guidelines}"
    safe = validate_output(output)
    confidence = 0.85
    if not safe:
        return "Unsafe output blocked", 0.0
    return output, confidence
