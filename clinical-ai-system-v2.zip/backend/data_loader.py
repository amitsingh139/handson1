import pandas as pd

def load_data():
    df = pd.read_csv("mimic_sample.csv")
    features = ["age","heart_rate","bp","glucose","gender","ethnicity"]
    target = "mortality"
    return df.dropna(), features, target
