from xgboost import XGBClassifier
import numpy as np

class RiskModel:
    def __init__(self):
        self.model = XGBClassifier()

    def train(self, X, y):
        self.model.fit(X, y)

    def predict(self, patient):
        prob = self.model.predict_proba([patient])[0][1]
        confidence = max(prob, 1-prob)
        return prob, confidence
