from fastapi import FastAPI
from data_loader import load_data
from model import RiskModel
from fairness import compute_bias_score
from explain import Explainer
from risk_engine import categorize_risk, get_complications_with_probabilities
from guidelines import who_guidelines
from genai import generate_decision
from metrics import llm_confidence, explanation_quality, overall_score

app = FastAPI()

df, features, target = load_data()
X = df[features]
y = df[target]

model = RiskModel()
model.train(X,y)

explainer = Explainer(model.model)

@app.post("/predict")
def predict(patient: dict):
    vals = [patient[f] for f in features]

    risk, risk_conf = model.predict(vals)

    # dummy predictions for fairness
    y_pred = y
    bias_score, bias_flag = compute_bias_score(y, y_pred, df["gender"])

    explanation = explainer.explain(vals)

    risk_cat = categorize_risk(risk)
    comp = get_complications_with_probabilities(risk)

    guidelines = who_guidelines(patient, risk_cat)

    decision, llm_conf = generate_decision(patient, risk, comp, guidelines)

    exp_quality = explanation_quality(explanation)

    final_score = overall_score(risk_conf, bias_score, llm_conf)

    return {
        "risk": risk,
        "risk_confidence": risk_conf,
        "bias_score": bias_score,
        "bias_flag": bias_flag,
        "llm_confidence": llm_conf,
        "explanation_quality": exp_quality,
        "overall_score": final_score,
        "complications": comp,
        "guidelines": guidelines,
        "decision": decision
    }
